﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2_3_Tree
{
    class TwoThreeTreeNode
    {

        #region Properties

        public int Value { get; set; }

        public int Key { get; set; }
        public int leftMAX { get; set; }
        public int middleMAX { get; set; }
        public int MAX { get; set; }
        public TwoThreeTreeNode LeftChild { get; set; }
        public TwoThreeTreeNode MiddleChild { get; set; }
        public TwoThreeTreeNode RightChild { get; set; }
        public TwoThreeTreeNode Parent { get; set; }


        public bool IsLeaf
        {
            get { return LeftChild == null && RightChild == null && MiddleChild == null; }
        }
        public bool HasLeftChild
        {
            get { return LeftChild != null; }
        }
        public bool HasMiddleChild
        {
            get { return LeftChild != null; }
        }
        public bool HasRightChild
        {
            get { return RightChild != null; }
        }


        #endregion

        public TwoThreeTreeNode(int value)
        {
            this.Value = value;
        }

        #region IComparable Members

        public int CompareTo(object obj)
        {
            TwoThreeTreeNode node = obj as TwoThreeTreeNode;

            return this.Value.CompareTo(node.Value);
        }

        #endregion

        public static bool operator <(TwoThreeTreeNode node1, TwoThreeTreeNode node2)
        {
            return node1.Value.CompareTo(node2.Value) < 0;
        }
        public static bool operator >(TwoThreeTreeNode node1, TwoThreeTreeNode node2)
        {
            return node1.Value.CompareTo(node2.Value) > 0;
        }

    }


    class TwoThreeTree
    {
        #region Properties

        public TwoThreeTreeNode Root { get; set; }
        private List<int> _list;
        public int Count { get; private set; }
        public int intNULL = -10000000;



        #endregion

        public TwoThreeTree()
        {
            Count = 0;

            _list = new List<int>();
        }

        public TwoThreeTree(int value)
            : this()
        {
            Add(value);
        }

        #region Find Node

        public virtual bool Search(TwoThreeTreeNode node, int value)
        {
            if (node == null)
                return false;

            if (node.Value == value)
                return true;
            else
            {
                if (value <= node.leftMAX)
                    return Search(node.LeftChild, value);
                else if (value <= node.middleMAX)
                    return Search(node.MiddleChild, value);
                else
                    return Search(node.RightChild, value);
            }
        }

        public virtual Queue<int> FindPath(int value)
        {
            Queue<int> q = new Queue<int>();

            TwoThreeTreeNode node = this.Root;
            bool isFounded = false;

            while (node != null)
            {
                if (node.Value == value)
                {
                    isFounded = true;
                    break;
                }
                else
                {
                    if (value <= node.leftMAX)
                        node = node.LeftChild;
                    else if (value <= node.middleMAX)
                        node = node.MiddleChild;
                    else
                        node = node.RightChild;

                    if (node != null) q.Enqueue(node.Value);
                }
            }
            if (!isFounded)
            {
                q.Clear();
                q = null;
            }

            return q;
        }

        #endregion

        #region Add Node
        public virtual void Add(params int[] values)
        {
            Array.ForEach(values, value => Add(value));
        }
        public virtual bool Add(int value)
        {
            if (Search(Root, value)) return false;
            Count++;
            TwoThreeTreeNode node = new TwoThreeTreeNode(value);
            node.MAX = node.Value;
            node.Key = Count;
            if (Root == null)
            {
                
                Root = node;
                return true;
            }
            else if (Root.IsLeaf)
            {
                if (Root.Value == node.Value) return false;
                Count++;
                TwoThreeTreeNode Pnode = new TwoThreeTreeNode(intNULL);
                Pnode.Key = Count;
                if (Root.Value < node.Value)
                {
                    TwoThreeTreeNode L = Root, M = node;
                    L.Parent = Pnode; Pnode.LeftChild = L;
                    M.Parent = Pnode; Pnode.MiddleChild = M;
                    Pnode.leftMAX = L.MAX;
                    Pnode.middleMAX = M.MAX;
                    Pnode.MAX = Math.Max(L.MAX, M.MAX);
                }
                else
                {
                    TwoThreeTreeNode L = node, M = Root;
                    L.Parent = Pnode; Pnode.LeftChild = L;
                    M.Parent = Pnode; Pnode.MiddleChild = M;
                    Pnode.leftMAX = L.MAX;
                    Pnode.middleMAX = M.MAX;
                    Pnode.MAX = Math.Max(L.MAX, M.MAX);
                }
                Root = Pnode;
                
                return true;
            }
            
            else return Add(Root, node);
        }

        public bool ChildIsLead(TwoThreeTreeNode node)
        {
            bool check = true;
            TwoThreeTreeNode L = null;
            if (node.LeftChild != null) L = node.LeftChild;
            TwoThreeTreeNode M = null;
            if (node.MiddleChild != null) M = node.MiddleChild;
            TwoThreeTreeNode R = null;
            if (node.RightChild != null) R = node.RightChild;

            if (L != null)
            {
                if (!L.IsLeaf) check = false;
            }
            if (M != null)
            {
                if (!M.IsLeaf) check = false;
            }
            if (R != null)
            {
                if (!R.IsLeaf) check = false;
            }
            return check;
        }

        public void FixParent(TwoThreeTreeNode node)
        {
            if (node.Parent == null) return;
            if (node == node.Parent.LeftChild)
            {
                node.Parent.leftMAX = node.MAX;
                return;
            }
            else if (node == node.Parent.MiddleChild)
            {
                node.Parent.middleMAX = node.MAX;
                return;
            }
            else if (node == node.Parent.RightChild)
            {
                node.Parent.MAX = node.MAX;
                FixParent(node.Parent);
                return;
            }
        }

        public void InsertIntoRoot(TwoThreeTreeNode node)
        {

            Count++;
            TwoThreeTreeNode Pnode = new TwoThreeTreeNode(intNULL);
            Pnode.Key = Count;
            if (Root.MAX < node.MAX)
            {
                TwoThreeTreeNode L = Root, M = node;
                L.Parent = Pnode; Pnode.LeftChild = L;
                M.Parent = Pnode; Pnode.MiddleChild = M;
                Pnode.leftMAX = L.MAX;
                Pnode.middleMAX = M.MAX;
                Pnode.MAX = Math.Max(L.MAX, M.MAX);
            }
            else
            {
                TwoThreeTreeNode L = node, M = Root;
                L.Parent = Pnode; Pnode.LeftChild = L;
                M.Parent = Pnode; Pnode.MiddleChild = M;
                Pnode.leftMAX = L.MAX;
                Pnode.middleMAX = M.MAX;
                Pnode.MAX = Math.Max(L.MAX, M.MAX);
            }
            Root = Pnode;
        }

        public void InsertIntoThreeNode(TwoThreeTreeNode parentNode, TwoThreeTreeNode son, TwoThreeTreeNode node)
        {
            if (parentNode.HasLeftChild && parentNode.HasMiddleChild && !parentNode.HasRightChild) // 2 children
            {
                if (son == parentNode.LeftChild)
                {
                    TwoThreeTreeNode M = parentNode.MiddleChild;
                    node.Parent = parentNode; parentNode.MiddleChild = node;
                    parentNode.RightChild = M;
                    parentNode.leftMAX = parentNode.LeftChild.MAX;
                    parentNode.middleMAX = parentNode.MiddleChild.MAX;
                    parentNode.MAX = parentNode.MAX = Math.Max(Math.Max(parentNode.MAX, node.MAX), Math.Max(parentNode.LeftChild.MAX, parentNode.MiddleChild.MAX));
                    FixParent(parentNode);
                }
                else
                {
                    node.Parent = parentNode; parentNode.RightChild = node;
                    parentNode.leftMAX = parentNode.LeftChild.MAX;
                    parentNode.middleMAX = parentNode.MiddleChild.MAX;
                    parentNode.MAX = parentNode.MAX = Math.Max(Math.Max(parentNode.MAX, node.MAX), Math.Max(parentNode.LeftChild.MAX, parentNode.MiddleChild.MAX));
                    FixParent(parentNode);
                }
                return;
            }
            else // 3 children
            {


                TwoThreeTreeNode L = parentNode.LeftChild;
                TwoThreeTreeNode M = parentNode.MiddleChild;
                TwoThreeTreeNode R = parentNode.RightChild;

                if (son == parentNode.LeftChild)
                {
                    node.Parent = parentNode; parentNode.MiddleChild = node;
                    parentNode.RightChild = null;
                    parentNode.leftMAX = parentNode.LeftChild.MAX;
                    parentNode.middleMAX = parentNode.MiddleChild.MAX;
                    parentNode.MAX = Math.Max(parentNode.LeftChild.MAX, parentNode.MiddleChild.MAX);
                    M.Parent = null;
                    R.Parent = null;
                    FixParent(parentNode);

                    Count++;
                    TwoThreeTreeNode Pnode = new TwoThreeTreeNode(intNULL);
                    Pnode.Key = Count;
                    M.Parent = Pnode; Pnode.LeftChild = M;
                    R.Parent = Pnode; Pnode.MiddleChild = R;
                    Pnode.leftMAX = M.MAX;
                    Pnode.middleMAX = R.MAX;
                    Pnode.MAX = Math.Max(M.MAX, R.MAX);
                    if (parentNode.Parent == null) InsertIntoRoot(Pnode);
                    else InsertIntoThreeNode(parentNode.Parent, parentNode, Pnode);
                }
                else if (son == parentNode.MiddleChild)
                {
                    parentNode.RightChild = null;
                    parentNode.leftMAX = parentNode.LeftChild.MAX;
                    parentNode.middleMAX = parentNode.MiddleChild.MAX;
                    parentNode.MAX = Math.Max(parentNode.LeftChild.MAX, parentNode.MiddleChild.MAX);
                    R.Parent = null;
                    FixParent(parentNode);

                    Count++;
                    TwoThreeTreeNode Pnode = new TwoThreeTreeNode(intNULL);
                    Pnode.Key = Count;
                    node.Parent = Pnode; Pnode.LeftChild = node;
                    R.Parent = Pnode; Pnode.MiddleChild = R;
                    Pnode.leftMAX = node.MAX;
                    Pnode.middleMAX = R.MAX;
                    Pnode.MAX = Math.Max(node.MAX, R.MAX);
                    if (parentNode.Parent == null) InsertIntoRoot(Pnode);
                    else InsertIntoThreeNode(parentNode.Parent, parentNode, Pnode);
                }
                else
                {
                    parentNode.RightChild = null;
                    parentNode.leftMAX = parentNode.LeftChild.MAX;
                    parentNode.middleMAX = parentNode.MiddleChild.MAX;
                    parentNode.MAX = Math.Max(parentNode.LeftChild.MAX, parentNode.MiddleChild.MAX);
                    R.Parent = null;
                    FixParent(parentNode);

                    Count++;
                    TwoThreeTreeNode Pnode = new TwoThreeTreeNode(intNULL);
                    Pnode.Key = Count;
                    if (R.MAX < node.MAX)
                    {
                        R.Parent = Pnode; Pnode.LeftChild = R;
                        node.Parent = Pnode; Pnode.MiddleChild = node;
                        Pnode.leftMAX = R.MAX;
                        Pnode.middleMAX = node.MAX;
                    }
                    else
                    {
                        node.Parent = Pnode; Pnode.LeftChild = node;
                        R.Parent = Pnode; Pnode.MiddleChild = R;
                        Pnode.leftMAX = node.MAX;
                        Pnode.middleMAX = R.MAX;
                    }
                    Pnode.MAX = Math.Max(node.MAX, R.MAX);
                    if (parentNode.Parent == null) InsertIntoRoot(Pnode);
                    else InsertIntoThreeNode(parentNode.Parent, parentNode, Pnode);
                }
            }
        }

        private bool Add(TwoThreeTreeNode parentNode, TwoThreeTreeNode node)
        {
            if (parentNode.IsLeaf && parentNode.Value == node.Value) return false;

            if (!ChildIsLead(parentNode))
            {
                if (node.Value <= parentNode.leftMAX) return Add(parentNode.LeftChild, node);
                else if (node.Value <= parentNode.middleMAX) return Add(parentNode.MiddleChild, node);
                else if(parentNode.RightChild != null) return Add(parentNode.RightChild, node);
                else return Add(parentNode.MiddleChild, node);
            }
            else
            {
                if (parentNode.HasLeftChild && parentNode.HasMiddleChild && !parentNode.HasRightChild) // 2 children
                {
                    if (node.Value <= parentNode.leftMAX)
                    {
                        TwoThreeTreeNode L = parentNode.LeftChild;
                        TwoThreeTreeNode M = parentNode.MiddleChild;
                        node.Parent = parentNode; parentNode.LeftChild = node;
                        parentNode.MiddleChild = L;
                        parentNode.RightChild = M;
                        parentNode.leftMAX = parentNode.LeftChild.MAX;
                        parentNode.middleMAX = parentNode.MiddleChild.MAX;
                        parentNode.MAX = Math.Max(Math.Max(parentNode.LeftChild.MAX, parentNode.MiddleChild.MAX), parentNode.RightChild.MAX);
                    }
                    else if (node.Value <= parentNode.middleMAX)
                    {
                        TwoThreeTreeNode M = parentNode.MiddleChild;
                        node.Parent = parentNode; parentNode.MiddleChild = node;
                        parentNode.RightChild = M;
                        parentNode.middleMAX = parentNode.MiddleChild.MAX;
                        parentNode.MAX = Math.Max(Math.Max(parentNode.LeftChild.MAX, parentNode.MiddleChild.MAX), parentNode.RightChild.MAX);
                    }
                    else
                    {
                        node.Parent = parentNode; parentNode.RightChild = node;
                        parentNode.MAX = Math.Max(Math.Max(parentNode.LeftChild.MAX, parentNode.MiddleChild.MAX), parentNode.RightChild.MAX);
                        FixParent(parentNode);

                    }
                    
                    return true;
                }
                else // 3 children
                {
                    TwoThreeTreeNode L = parentNode.LeftChild;
                    TwoThreeTreeNode M = parentNode.MiddleChild;
                    TwoThreeTreeNode R = parentNode.RightChild;

                    if (node.Value <= parentNode.leftMAX)
                    {
                        node.Parent = parentNode; parentNode.LeftChild = node;
                        parentNode.MiddleChild = L;
                        parentNode.RightChild = null;
                        parentNode.leftMAX = parentNode.LeftChild.MAX;
                        parentNode.middleMAX = parentNode.MiddleChild.MAX;
                        parentNode.MAX = Math.Max(parentNode.LeftChild.MAX, parentNode.MiddleChild.MAX);
                        M.Parent = null;
                        R.Parent = null;
                        FixParent(parentNode);

                        Count++;
                        TwoThreeTreeNode Pnode = new TwoThreeTreeNode(intNULL);
                        Pnode.Key = Count;
                        M.Parent = Pnode; Pnode.LeftChild = M;
                        R.Parent = Pnode; Pnode.MiddleChild = R;
                        Pnode.leftMAX = M.MAX;
                        Pnode.middleMAX = R.MAX;
                        Pnode.MAX = Math.Max(M.MAX, R.MAX);
                        if (parentNode.Parent == null) InsertIntoRoot(Pnode);
                        else InsertIntoThreeNode(parentNode.Parent, parentNode, Pnode);
                    }
                    else if (node.Value <= parentNode.middleMAX)
                    {
                        node.Parent = parentNode; parentNode.MiddleChild = node;
                        parentNode.RightChild = null;
                        parentNode.leftMAX = parentNode.LeftChild.MAX;
                        parentNode.middleMAX = parentNode.MiddleChild.MAX;
                        parentNode.MAX = Math.Max(parentNode.LeftChild.MAX, parentNode.MiddleChild.MAX);
                        M.Parent = null;
                        R.Parent = null;
                        FixParent(parentNode);

                        Count++;
                        TwoThreeTreeNode Pnode = new TwoThreeTreeNode(intNULL);
                        Pnode.Key = Count;
                        M.Parent = Pnode; Pnode.LeftChild = M;
                        R.Parent = Pnode; Pnode.MiddleChild = R;
                        Pnode.leftMAX = M.MAX;
                        Pnode.middleMAX = R.MAX;
                        Pnode.MAX = Math.Max(M.MAX, R.MAX);
                        if (parentNode.Parent == null) InsertIntoRoot(Pnode);
                        else InsertIntoThreeNode(parentNode.Parent, parentNode, Pnode);
                    }
                    else if (node.Value <= parentNode.RightChild.Value)
                    {
                        parentNode.RightChild = null;
                        parentNode.leftMAX = parentNode.LeftChild.MAX;
                        parentNode.middleMAX = parentNode.MiddleChild.MAX;
                        parentNode.MAX = Math.Max(parentNode.LeftChild.MAX, parentNode.MiddleChild.MAX);
                        R.Parent = null;
                        FixParent(parentNode);

                        Count++;
                        TwoThreeTreeNode Pnode = new TwoThreeTreeNode(intNULL);
                        Pnode.Key = Count;
                        node.Parent = Pnode; Pnode.LeftChild = node;
                        R.Parent = Pnode; Pnode.MiddleChild = R;
                        Pnode.leftMAX = node.MAX;
                        Pnode.middleMAX = R.MAX;
                        Pnode.MAX = Math.Max(node.MAX, R.MAX);
                        if (parentNode.Parent == null) InsertIntoRoot(Pnode);
                        else InsertIntoThreeNode(parentNode.Parent, parentNode, Pnode);
                    }
                    else
                    {
                        parentNode.RightChild = null;
                        parentNode.leftMAX = parentNode.LeftChild.MAX;
                        parentNode.middleMAX = parentNode.MiddleChild.MAX;
                        parentNode.MAX = Math.Max(parentNode.LeftChild.MAX, parentNode.MiddleChild.MAX);
                        R.Parent = null;
                        FixParent(parentNode);

                        Count++;
                        TwoThreeTreeNode Pnode = new TwoThreeTreeNode(intNULL);
                        Pnode.Key = Count;
                        R.Parent = Pnode; Pnode.LeftChild = R;
                        node.Parent = Pnode; Pnode.MiddleChild = node;
                        Pnode.leftMAX = R.MAX;
                        Pnode.middleMAX = node.MAX;
                        Pnode.MAX = Math.Max(node.MAX, R.MAX);
                        if (parentNode.Parent == null) InsertIntoRoot(Pnode);
                        else InsertIntoThreeNode(parentNode.Parent, parentNode, Pnode);
                    }
                    
                    return true;
                }
            }
        }

        #endregion

        #region Remove Node

        public virtual bool Remove(int value)
        {
            if (!Search(Root, value)) return false;
            if (Root == null) return false;
            if (Root.Value == value)
            {
                
                Root = null;
                return true;
            }
            else
            {
                TwoThreeTreeNode parentNode = Root;

                while (!ChildIsLead(parentNode))
                {
                    if (value <= parentNode.leftMAX) parentNode = parentNode.LeftChild;
                    else if (value <= parentNode.middleMAX) parentNode = parentNode.MiddleChild;
                    else parentNode = parentNode.RightChild;
                }
                if (parentNode == null) return false;
                TwoThreeTreeNode Node;
                if (value == parentNode.LeftChild.Value) Node = parentNode.LeftChild;
                else if (value == parentNode.MiddleChild.Value) Node = parentNode.MiddleChild;
                else Node = parentNode.RightChild;
                return Remove(parentNode, Node);

            }
        }

        private bool Remove(TwoThreeTreeNode parentNode, TwoThreeTreeNode node)
        {




            if (parentNode.LeftChild != node && parentNode.MiddleChild != node && parentNode.RightChild != node) return false;

            if (parentNode.HasLeftChild && parentNode.HasMiddleChild && parentNode.HasRightChild) // 3 children
            {
                TwoThreeTreeNode L = parentNode.LeftChild;
                TwoThreeTreeNode M = parentNode.MiddleChild;
                TwoThreeTreeNode R = parentNode.RightChild;

                if (parentNode.LeftChild == node)
                {
                    parentNode.LeftChild = M;
                    parentNode.MiddleChild = R;
                    parentNode.RightChild = null;
                }
                else if (parentNode.MiddleChild == node)
                {
                    parentNode.MiddleChild = R;
                    parentNode.RightChild = null;
                }
                else
                {
                    parentNode.RightChild = null;
                }
                parentNode.leftMAX = parentNode.LeftChild.MAX;
                parentNode.middleMAX = parentNode.MiddleChild.MAX;
                parentNode.MAX = Math.Max(parentNode.LeftChild.MAX, parentNode.MiddleChild.MAX);
                FixParent(parentNode);
                
                return true;

            }
            else // 2 children
            {
                if (parentNode == Root)
                {
                    TwoThreeTreeNode L = parentNode.LeftChild;
                    TwoThreeTreeNode M = parentNode.MiddleChild;
                    L.Parent = null; M.Parent = null;
                    if (parentNode.LeftChild == node) Root = M;
                    else Root = L;
                }
                else
                {
                    TwoThreeTreeNode GrandParent = parentNode.Parent;
                    if (parentNode == GrandParent.LeftChild)
                    {
                        if (GrandParent.MiddleChild.HasLeftChild && GrandParent.MiddleChild.HasMiddleChild && GrandParent.MiddleChild.HasRightChild)
                        {
                            TwoThreeTreeNode L = parentNode.LeftChild;
                            TwoThreeTreeNode M = parentNode.MiddleChild;

                            TwoThreeTreeNode SL = GrandParent.MiddleChild.LeftChild;
                            TwoThreeTreeNode SM = GrandParent.MiddleChild.MiddleChild;
                            TwoThreeTreeNode SR = GrandParent.MiddleChild.RightChild;
                            if (L == node)
                            {
                                parentNode.LeftChild = M;
                                SL.Parent = parentNode; parentNode.MiddleChild = SL;
                                
                            }
                            else
                            {
                                SL.Parent = parentNode; parentNode.MiddleChild = SL;
                                
                            }
                            parentNode.leftMAX = parentNode.LeftChild.MAX;
                            parentNode.middleMAX = parentNode.MiddleChild.MAX;
                            parentNode.MAX = Math.Max(parentNode.LeftChild.MAX, parentNode.MiddleChild.MAX);

                            GrandParent.MiddleChild.LeftChild = SM;
                            GrandParent.MiddleChild.MiddleChild = SR;
                            GrandParent.MiddleChild.RightChild = null;
                            GrandParent.MiddleChild.leftMAX = GrandParent.MiddleChild.LeftChild.MAX;
                            GrandParent.MiddleChild.middleMAX = GrandParent.MiddleChild.MiddleChild.MAX;
                            GrandParent.MiddleChild.MAX = Math.Max(GrandParent.MiddleChild.LeftChild.MAX, GrandParent.MiddleChild.MiddleChild.MAX);
                            FixParent(parentNode);

                        }
                        else
                        {
                            TwoThreeTreeNode L = parentNode.LeftChild;
                            TwoThreeTreeNode M = parentNode.MiddleChild;
                            L.Parent = null; M.Parent = null;

                            TwoThreeTreeNode SL = GrandParent.MiddleChild.LeftChild;
                            TwoThreeTreeNode SM = GrandParent.MiddleChild.MiddleChild;


                            if (L == node)
                            {
                                M.Parent = GrandParent.MiddleChild; GrandParent.MiddleChild.LeftChild = M;
                                
                            }
                            else
                            {
                                M.Parent = GrandParent.MiddleChild; GrandParent.MiddleChild.LeftChild = L;
                            }
                            GrandParent.MiddleChild.MiddleChild = SL;
                            GrandParent.MiddleChild.RightChild = SM;
                            GrandParent.MiddleChild.leftMAX = GrandParent.MiddleChild.LeftChild.MAX;
                            GrandParent.MiddleChild.middleMAX = GrandParent.MiddleChild.MiddleChild.MAX;
                            GrandParent.MiddleChild.MAX = Math.Max(GrandParent.MiddleChild.LeftChild.MAX, GrandParent.MiddleChild.MiddleChild.MAX);
                            FixParent(parentNode);

                            Remove(GrandParent, GrandParent.LeftChild);
                            FixParent(GrandParent);
                        }
                    }
                    else if(parentNode == GrandParent.MiddleChild)
                    {
                        if (GrandParent.LeftChild.HasLeftChild && GrandParent.LeftChild.HasMiddleChild && GrandParent.LeftChild.HasRightChild)
                        {
                            TwoThreeTreeNode L = parentNode.LeftChild;
                            TwoThreeTreeNode M = parentNode.MiddleChild;

                            TwoThreeTreeNode SL = GrandParent.LeftChild.LeftChild;
                            TwoThreeTreeNode SM = GrandParent.LeftChild.MiddleChild;
                            TwoThreeTreeNode SR = GrandParent.LeftChild.RightChild;
                            if (L == node)
                            {
                                
                                SR.Parent = parentNode; parentNode.LeftChild = SR;
                                
                            }
                            else
                            {
                                parentNode.MiddleChild = L;
                                SR.Parent = parentNode; parentNode.LeftChild = SR;
                                
                            }
                            parentNode.leftMAX = parentNode.LeftChild.MAX;
                            parentNode.middleMAX = parentNode.MiddleChild.MAX;
                            parentNode.MAX = Math.Max(parentNode.LeftChild.MAX, parentNode.MiddleChild.MAX);

                            
                            GrandParent.LeftChild.RightChild = null;
                            GrandParent.LeftChild.leftMAX = GrandParent.LeftChild.LeftChild.MAX;
                            GrandParent.LeftChild.middleMAX = GrandParent.LeftChild.MiddleChild.MAX;
                            GrandParent.LeftChild.MAX = Math.Max(GrandParent.LeftChild.LeftChild.MAX, GrandParent.LeftChild.MiddleChild.MAX);
                            FixParent(parentNode);

                        }

                        else if(GrandParent.RightChild != null)
                        {
                            if(GrandParent.RightChild.HasLeftChild && GrandParent.RightChild.HasMiddleChild && GrandParent.RightChild.HasRightChild)
                            {
                                TwoThreeTreeNode L = parentNode.LeftChild;
                                TwoThreeTreeNode M = parentNode.MiddleChild;

                                TwoThreeTreeNode SL = GrandParent.RightChild.LeftChild;
                                TwoThreeTreeNode SM = GrandParent.RightChild.MiddleChild;
                                TwoThreeTreeNode SR = GrandParent.RightChild.RightChild;
                                if (L == node)
                                {
                                    parentNode.LeftChild = M;
                                    SL.Parent = parentNode; parentNode.MiddleChild = SL;

                                }
                                else
                                {
                                    SL.Parent = parentNode; parentNode.MiddleChild = SL;

                                }
                                parentNode.leftMAX = parentNode.LeftChild.MAX;
                                parentNode.middleMAX = parentNode.MiddleChild.MAX;
                                parentNode.MAX = Math.Max(parentNode.LeftChild.MAX, parentNode.MiddleChild.MAX);

                                GrandParent.RightChild.LeftChild = SM;
                                GrandParent.RightChild.MiddleChild = SR;
                                GrandParent.RightChild.RightChild = null;
                                GrandParent.RightChild.leftMAX = GrandParent.RightChild.LeftChild.MAX;
                                GrandParent.RightChild.middleMAX = GrandParent.RightChild.MiddleChild.MAX;
                                GrandParent.RightChild.MAX = Math.Max(GrandParent.RightChild.LeftChild.MAX, GrandParent.RightChild.MiddleChild.MAX);
                                FixParent(parentNode);
                            }
                            else if (GrandParent.RightChild.HasLeftChild && GrandParent.RightChild.HasMiddleChild && !GrandParent.RightChild.HasRightChild)
                            {
                                TwoThreeTreeNode L = parentNode.LeftChild;
                                TwoThreeTreeNode M = parentNode.MiddleChild;
                                L.Parent = null; M.Parent = null;

                                TwoThreeTreeNode SL = GrandParent.RightChild.LeftChild;
                                TwoThreeTreeNode SM = GrandParent.RightChild.MiddleChild;


                                if (L == node)
                                {
                                    M.Parent = GrandParent.RightChild; GrandParent.RightChild.LeftChild = M;

                                }
                                else
                                {
                                    M.Parent = GrandParent.RightChild; GrandParent.RightChild.LeftChild = L;
                                }
                                GrandParent.RightChild.MiddleChild = SL;
                                GrandParent.RightChild.RightChild = SM;
                                GrandParent.RightChild.leftMAX = GrandParent.RightChild.LeftChild.MAX;
                                GrandParent.RightChild.middleMAX = GrandParent.RightChild.MiddleChild.MAX;
                                GrandParent.RightChild.MAX = Math.Max(Math.Max(GrandParent.RightChild.LeftChild.MAX, GrandParent.RightChild.MiddleChild.MAX),GrandParent.RightChild.RightChild.MAX);
                                FixParent(parentNode);

                                Remove(GrandParent, GrandParent.MiddleChild);
                                FixParent(GrandParent);
                            }
                            else
                            {
                                TwoThreeTreeNode L = parentNode.LeftChild;
                                TwoThreeTreeNode M = parentNode.MiddleChild;
                                L.Parent = null; M.Parent = null;

                                TwoThreeTreeNode SL = GrandParent.LeftChild.LeftChild;
                                TwoThreeTreeNode SM = GrandParent.LeftChild.MiddleChild;


                                if (L == node)
                                {
                                    M.Parent = GrandParent.LeftChild; GrandParent.LeftChild.RightChild = M;

                                }
                                else
                                {
                                    M.Parent = GrandParent.LeftChild; GrandParent.LeftChild.RightChild = L;
                                }

                                GrandParent.LeftChild.leftMAX = GrandParent.LeftChild.LeftChild.MAX;
                                GrandParent.LeftChild.middleMAX = GrandParent.LeftChild.MiddleChild.MAX;
                                GrandParent.LeftChild.MAX = Math.Max(Math.Max(GrandParent.LeftChild.LeftChild.MAX, GrandParent.LeftChild.MiddleChild.MAX),GrandParent.LeftChild.RightChild.MAX);
                                FixParent(parentNode);

                                Remove(GrandParent, GrandParent.MiddleChild);
                                FixParent(GrandParent);
                            }
                        }
                        
                        else
                        {
                            TwoThreeTreeNode L = parentNode.LeftChild;
                            TwoThreeTreeNode M = parentNode.MiddleChild;
                            L.Parent = null; M.Parent = null;

                            TwoThreeTreeNode SL = GrandParent.LeftChild.LeftChild;
                            TwoThreeTreeNode SM = GrandParent.LeftChild.MiddleChild;


                            if (L == node)
                            {
                                M.Parent = GrandParent.LeftChild; GrandParent.LeftChild.RightChild = M;

                            }
                            else
                            {
                                M.Parent = GrandParent.LeftChild; GrandParent.LeftChild.RightChild = L;
                            }
                            
                            GrandParent.LeftChild.leftMAX = GrandParent.LeftChild.LeftChild.MAX;
                            GrandParent.LeftChild.middleMAX = GrandParent.LeftChild.MiddleChild.MAX;
                            GrandParent.LeftChild.MAX = Math.Max(Math.Max(GrandParent.LeftChild.LeftChild.MAX, GrandParent.LeftChild.MiddleChild.MAX), GrandParent.LeftChild.RightChild.MAX);
                            FixParent(parentNode);

                            Remove(GrandParent, GrandParent.MiddleChild);
                            FixParent(GrandParent);
                        }
                    }
                    else // RightChild
                    {
                        if (GrandParent.MiddleChild.HasLeftChild && GrandParent.MiddleChild.HasMiddleChild && GrandParent.MiddleChild.HasRightChild)
                        {
                            TwoThreeTreeNode L = parentNode.LeftChild;
                            TwoThreeTreeNode M = parentNode.MiddleChild;

                            TwoThreeTreeNode SL = GrandParent.MiddleChild.LeftChild;
                            TwoThreeTreeNode SM = GrandParent.MiddleChild.MiddleChild;
                            TwoThreeTreeNode SR = GrandParent.MiddleChild.RightChild;
                            if (L == node)
                            {

                                SR.Parent = parentNode; parentNode.LeftChild = SR;

                            }
                            else
                            {
                                parentNode.MiddleChild = L;
                                SR.Parent = parentNode; parentNode.LeftChild = SR;

                            }
                            parentNode.leftMAX = parentNode.LeftChild.MAX;
                            parentNode.middleMAX = parentNode.MiddleChild.MAX;
                            parentNode.MAX = Math.Max(parentNode.LeftChild.MAX, parentNode.MiddleChild.MAX);


                            GrandParent.MiddleChild.RightChild = null;
                            GrandParent.MiddleChild.leftMAX = GrandParent.MiddleChild.LeftChild.MAX;
                            GrandParent.MiddleChild.middleMAX = GrandParent.MiddleChild.MiddleChild.MAX;
                            GrandParent.MiddleChild.MAX = Math.Max(GrandParent.MiddleChild.LeftChild.MAX, GrandParent.MiddleChild.MiddleChild.MAX);
                            FixParent(parentNode);

                        }
                        else
                        {
                            TwoThreeTreeNode L = parentNode.LeftChild;
                            TwoThreeTreeNode M = parentNode.MiddleChild;
                            L.Parent = null; M.Parent = null;

                            TwoThreeTreeNode SL = GrandParent.MiddleChild.LeftChild;
                            TwoThreeTreeNode SM = GrandParent.MiddleChild.MiddleChild;


                            if (L == node)
                            {
                                M.Parent = GrandParent.MiddleChild; GrandParent.MiddleChild.RightChild = M;

                            }
                            else
                            {
                                M.Parent = GrandParent.MiddleChild; GrandParent.MiddleChild.RightChild = L;
                            }

                            GrandParent.MiddleChild.leftMAX = GrandParent.MiddleChild.LeftChild.MAX;
                            GrandParent.MiddleChild.middleMAX = GrandParent.MiddleChild.MiddleChild.MAX;
                            GrandParent.MiddleChild.MAX = Math.Max(Math.Max(GrandParent.MiddleChild.LeftChild.MAX, GrandParent.MiddleChild.MiddleChild.MAX),GrandParent.MiddleChild.RightChild.MAX);
                            FixParent(parentNode);

                            Remove(GrandParent, GrandParent.RightChild);
                            FixParent(GrandParent);
                        }
                    }
                }
                
                return true;
            }

        }

        #endregion

        public virtual int GetHeight()
        {
            return this.GetHeight(this.Root);
        }
        private int GetHeight(TwoThreeTreeNode startNode)
        {
            if (startNode == null)
                return 0;
            else
                return 1 + Math.Max(GetHeight(startNode.LeftChild), GetHeight(startNode.RightChild));
        }

        public virtual void ClearChildren(TwoThreeTreeNode node)
        {

            if (node.HasLeftChild)
            {
                ClearChildren(node.LeftChild);
                node.LeftChild.Parent = null;
                
                node.LeftChild = null;
            }
            if (node.HasMiddleChild)
            {
                ClearChildren(node.MiddleChild);
                node.MiddleChild.Parent = null;

                node.MiddleChild = null;
            }
            if (node.HasRightChild)
            {
                ClearChildren(node.RightChild);
                node.RightChild.Parent = null;
                
                node.RightChild = null;
            }
        }

        public virtual void Clear()
        {
            if (Root == null)
                return;
            ClearChildren(Root);
            Root = null;
            Count = 0;
        }
    }


}
