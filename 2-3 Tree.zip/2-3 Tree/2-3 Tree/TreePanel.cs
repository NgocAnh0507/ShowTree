﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.Threading;
using System.Text.RegularExpressions;


namespace _2_3_Tree
{
    public partial class TreePanel : UserControl
    {
        #region Properties

        const int RADIUS = 30;
        const int DIAMETER = RADIUS * 2;
        const int HOR_DISTANCE = 7;
        const int VER_DISTANCE = 70;

        Pen _penNormal;
        Pen _penRed;
        Pen _penBlack;
        Pen _penHighLight;
        Brush _brush;
        Font _font;

        TwoThreeTree _Tree;

        float _leftRoot;
        float _minLeft;
        float _maxLeft;

        public Image Image
        {
            get { return pictureBox1.Image; }
        }

        Graphics _g;

        Queue<int> _queue;

        public int NodeCount
        {
            get { return _Tree.Count; }
        }
        public int TreeHeight
        {
            get { return _Tree.GetHeight(); }
        }
        #endregion

        public TreePanel()
        {
            InitializeComponent();

            _brush = new SolidBrush(Color.White);
            _penNormal = new Pen(Color.DarkBlue, 3);
            _penRed = new Pen(Color.Red, 7);
            _penBlack = new Pen(Color.Black, 7);
            _penHighLight = new Pen(Color.Yellow, 7);
            _font = new Font("Arial", 11);
            _Tree = new TwoThreeTree();
        }

        private void TreePanel_Load(object sender, EventArgs e)
        {

        }

        private void DrawTreeNode(Graphics g, PointF p, TwoThreeTreeNode node, bool highlight)
        {

            if (node != null)
            {
                string text;
                if (node.IsLeaf) text = node.Value.ToString();
                else text = node.leftMAX.ToString() + "/" + node.middleMAX.ToString();
                SizeF size = g.MeasureString(text, _font);

                float ellipseWidth = RADIUS + size.Width;
                float ellipseHeight = RADIUS + size.Height;

                float left = p.X - ellipseWidth / 2;
                float top = p.Y - ellipseHeight / 2;

                Pen pen=_penNormal;

                int gap = Deep_Node(node.Key, node.MAX);

                if (node.HasLeftChild)
                {
                    PointF p1 = p;
                    PointF p2 = p;

                    p1.X = left + ellipseWidth / 2;
                    

                    p2.X -= Math.Abs(HOR_DISTANCE * gap * gap * gap);
                    p2.Y += VER_DISTANCE;

                    bool hlight = false;
                    
                    if (_queue != null && _queue.Count > 0)
                    {
                        if (_queue.Peek() == node.LeftChild.Value)
                        {
                            _queue.Dequeue();
                            pen = _penHighLight;
                            hlight = true;
                        }
                    }

                    g.DrawLine(_penNormal, p1, p2);

                    DrawTreeNode(g, p2, node.LeftChild, hlight);

                    if (p2.X < _minLeft)
                        _minLeft = p2.X;
                    if (p2.X > _maxLeft)
                        _maxLeft = p2.X;
                }
                if (node.HasMiddleChild)
                {
                    PointF p1 = p;
                    PointF p2 = p;

                    p1.X = left + ellipseWidth / 2;
                    

                    
                    p2.Y += VER_DISTANCE;

                    bool hlight = false;

                    if (_queue != null && _queue.Count > 0)
                    {
                        if (_queue.Peek() == node.MiddleChild.Value)
                        {
                            _queue.Dequeue();
                            pen = _penHighLight;
                            hlight = true;
                        }
                    }

                    g.DrawLine(_penNormal, p1, p2);

                    DrawTreeNode(g, p2, node.MiddleChild, hlight);

                    if (p2.X < _minLeft)
                        _minLeft = p2.X;
                    if (p2.X > _maxLeft)
                        _maxLeft = p2.X;
                }
                if (node.HasRightChild)
                {
                    PointF p1 = p;
                    PointF p2 = p;
                    p1.X = left + ellipseWidth / 2;
                    
                    p2.X += Math.Abs(HOR_DISTANCE * gap * gap * gap);
                    p2.Y += VER_DISTANCE;

                    
                    bool hlight = false;
                    if (_queue != null && _queue.Count > 0)
                    {
                        if (_queue.Peek() == node.RightChild.Value)
                        {
                            _queue.Dequeue();
                            pen = _penHighLight;
                            hlight = true;
                        }
                    }

                    g.DrawLine(_penNormal, p1, p2);

                    DrawTreeNode(g, p2, node.RightChild, hlight);

                    if (p2.X < _minLeft)
                        _minLeft = p2.X;
                    if (p2.X > _maxLeft)
                        _maxLeft = p2.X;
                }

                if (node == _Tree.Root) highlight = false;
                if (highlight) pen = _penHighLight;
                

                g.FillEllipse(_brush, left, top, ellipseWidth, ellipseHeight);
                g.DrawEllipse(pen, left, top, ellipseWidth, ellipseHeight);
                
                g.DrawString(text, _font, Brushes.Black, left + RADIUS / 2, top + RADIUS / 2);

            }
        }

        public int Deep_Node(int key, int node)
        {
            TwoThreeTreeNode CurentNode = _Tree.Root, C;
            int kq = 0;
            while (key != CurentNode.Key)
            {
                if (node <= CurentNode.leftMAX)
                {
                    C = CurentNode.LeftChild;
                    CurentNode = C;
                }
                else if(node <= CurentNode.middleMAX)
                {
                    C = CurentNode.MiddleChild;
                    CurentNode = C;
                }
                else
                {
                    C = CurentNode.RightChild;
                    CurentNode = C;
                }
                kq++;
            }
            int H = TreeHeight;
            return (H - kq);
        }

        private void CalculateSize(Graphics g, float left, TwoThreeTreeNode node)
        {
            if (node != null)
            {
                string text;
                if (node.IsLeaf) text = node.Value.ToString();
                else text = node.leftMAX.ToString() + "/" + node.middleMAX.ToString();
                SizeF size = g.MeasureString(text, pictureBox1.Font);

                float x = left - (RADIUS + size.Width) / 2;
                int gap = Deep_Node(node.Key, node.MAX);



                if (node.HasLeftChild)
                {
                    float p2 = x - Math.Abs(HOR_DISTANCE * gap * gap * gap);
                    if (p2 < _minLeft)
                        _minLeft = p2;
                    if (p2 > _maxLeft)
                        _maxLeft = p2;

                    CalculateSize(g, p2, node.LeftChild);
                }
                if (node.HasMiddleChild)
                {
                    float p2 = x ;
                    if (p2 < _minLeft)
                        _minLeft = p2;
                    if (p2 > _maxLeft)
                        _maxLeft = p2;

                    CalculateSize(g, p2, node.MiddleChild);
                }
                if (node.HasRightChild)
                {
                    float p2 = x + Math.Abs(HOR_DISTANCE * gap * gap * gap);

                    if (p2 < _minLeft)
                        _minLeft = p2;
                    if (p2 > _maxLeft)
                        _maxLeft = p2;

                    CalculateSize(g, p2, node.RightChild);
                }
            }
        }

        private void BeginDraw()
        {
            BeginDraw(false);
        }
        private void BeginDraw(bool resetAll)
        {

            if (resetAll)
            {
                if (pictureBox1.Image != null)
                    pictureBox1.Image.Dispose();

                _leftRoot = pictureBox1.Width / 2;
                _minLeft = _leftRoot;
                _maxLeft = _leftRoot;

                using (Graphics g = pictureBox1.CreateGraphics())
                {
                    CalculateSize(g, _leftRoot, _Tree.Root);
                }



                _leftRoot -= _minLeft;

                _leftRoot += 230;
                _maxLeft -= _minLeft;
                _minLeft = 0;

                _maxLeft += 500;
                //pictureBox1.Image.Width = (int)_maxLeft;
                //pictureBox1.Image.Height = (_Tree.GetHeight() + 1) * VER_DISTANCE + 20;
            }
            Image img = new Bitmap((int)_maxLeft, (_Tree.GetHeight() + 1) * VER_DISTANCE + 210);

            if (_g != null)
            {
                _g.Dispose();
                pictureBox1.Image.Dispose();
            }

            pictureBox1.Image = img;// new Bitmap(pictureBox1.Width, pictureBox1.Height);
            _g = Graphics.FromImage(pictureBox1.Image);
            _g.SmoothingMode = SmoothingMode.AntiAlias;
            DrawTreeNode(_g, new PointF(_leftRoot, DIAMETER * 2), _Tree.Root, true);
        }

        public bool AddNode(int value)
        {
            if (!_Tree.Add(value))
            {
                txtOutput.Text = "Tree already contain an node with value " + value;
                txtOutput.SelectAll();
                return false;
            }

            txtOutput.Clear();
            BeginDraw(true);
            return true;
        }

        public bool SearchNode(int value)
        {
            _queue = _Tree.FindPath(value);
            if (_queue == null)
            {
                txtOutput.Text = "Tree does not contain value " + value;
                txtOutput.SelectAll();
                return false;
            }
            txtOutput.Clear();
            BeginDraw();
            return true;
        }

        public bool DeleteNode(int value)
        {
            if (!_Tree.Remove(value))
            {
                txtOutput.Text = "Tree does not contain value " + value;
                txtOutput.SelectAll();
                return false;
            }
            txtOutput.Clear();
            BeginDraw();
            return true;
        }

        private void txtOutput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData != Keys.Enter)
                return;
            try
            {
                string str = txtOutput.Text;
                str = Regex.Replace(str, @"\s+", " ");
                str = Regex.Replace(str, @",\s", " ");
                string[] s = str.Split(' ', ',');
                switch (s[0].ToLower())
                {

                    case "clear":
                        _Tree.Clear();
                        txtOutput.Clear();
                        BeginDraw();
                        break;
                    case "add":
                        for (int i = 1; i < s.Length; i++)
                            AddNode(int.Parse(s[i]));
                        break;
                    case "del":
                        DeleteNode(int.Parse(s[1]));
                        break;
                    case "delete":
                        DeleteNode(int.Parse(s[1]));
                        break;
                    case "find":
                        SearchNode(int.Parse(s[1]));
                        break;
                    case "search":
                        SearchNode(int.Parse(s[1]));
                        break;

                    case "exit":
                        this.ParentForm.Close();
                        break;
                    default:
                        txtOutput.Text = "Invalid command";
                        break;
                }

            }
            catch (Exception ex)
            {
                txtOutput.Text = ex.Message;
                txtOutput.SelectAll();
            }
            finally
            {
                txtOutput.SelectAll();
            }

        }

    }
}
