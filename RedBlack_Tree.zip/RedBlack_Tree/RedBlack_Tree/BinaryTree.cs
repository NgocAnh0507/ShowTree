﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace Y2Collections
{


    class Y2BinaryTreeNode<T> : IComparable
    where T : IComparable
    {

        #region Properties

        public T Value { get; set; }

        public int Color { get; set; }
        public Y2BinaryTreeNode<T> LeftChild { get; set; }
        public Y2BinaryTreeNode<T> RightChild { get; set; }
        public Y2BinaryTreeNode<T> Parent { get; set; }
        public Y2BinaryTreeNode<T> Uncle { get; set; }
        public Y2BinaryTreeNode<T> GrandParent { get; set; }

        public bool IsLeaf
        {
            get { return LeftChild == null && RightChild == null; }
        }
        public bool HasLeftChild
        {
            get { return LeftChild != null; }
        }
        public bool HasRightChild
        {
            get { return RightChild != null; }
        }

        
        #endregion

        public Y2BinaryTreeNode(T value)
        {
            this.Value = value;
        }

        #region IComparable Members

        public int CompareTo(object obj)
        {
            Y2BinaryTreeNode<T> node = obj as Y2BinaryTreeNode<T>;

            return this.Value.CompareTo(node.Value);
        }

        #endregion

        public static bool operator <(Y2BinaryTreeNode<T> node1, Y2BinaryTreeNode<T> node2)
        {
            return node1.Value.CompareTo(node2.Value) < 0;
        }
        public static bool operator >(Y2BinaryTreeNode<T> node1, Y2BinaryTreeNode<T> node2)
        {
            return node1.Value.CompareTo(node2.Value) > 0;
        }
    }

    class Y2BinaryTree<T>
    where T : IComparable
    {
        #region Properties

        public Y2BinaryTreeNode<T> Root { get; set; }
        private List<T> _list;
        public int Count { get; private set; }

        #endregion

        public Y2BinaryTree()
        {
            Count = 0;
            _list = new List<T>();
        }

        public Y2BinaryTree(T value)
            : this()
        {
            Add(value);
        }

        #region rotate

        public virtual void Rotate_Left(Y2BinaryTreeNode<T> node)
        {
            Y2BinaryTreeNode<T> R0 = node;
            Y2BinaryTreeNode<T> R = R0.RightChild;
            if (R == null) return;
            Y2BinaryTreeNode<T> LC = R.LeftChild;
            Y2BinaryTreeNode<T> P = R0.Parent;

            if (LC != null) { node.RightChild = LC; node.RightChild.Parent = node; }
            else node.RightChild = null;
            R.LeftChild = node; node.Parent = R;

            
            if (P != null)
            {
                bool left;
                if (R0 == P.LeftChild) left = true; else left = false;
                R.Parent = P; if (left) P.LeftChild = R; else P.RightChild = R;
                R.GrandParent = P.Parent;
                R.Uncle = sibling(R.Parent);
                
            }
            else
            {
                R.Parent = null;
                R.GrandParent = null;
                Root = R;
                R.Uncle = null;
            }
            if (node.RightChild != null)
            {
                node.RightChild.GrandParent = node.Parent;
                node.RightChild.Uncle = sibling(node);
            }
            node.GrandParent = node.Parent.Parent;
            node.Uncle = sibling(node.Parent);
            

        }

        public virtual void Rotate_Right(Y2BinaryTreeNode<T> node)
        {
            Y2BinaryTreeNode<T> R0 = node;
            Y2BinaryTreeNode<T> L = R0.LeftChild;
            if (L == null) return;
            Y2BinaryTreeNode<T> RC = L.RightChild;
            Y2BinaryTreeNode<T> P = R0.Parent;


            if (RC != null) { node.LeftChild = RC; node.LeftChild.Parent = node; }
            else node.LeftChild = null;
            L.RightChild = node; node.Parent = L;
            

            if (P != null)
            {
                bool left;
                if (R0 == P.LeftChild) left = true; else left = false;
                L.Parent = P; if (left) P.LeftChild = L; else P.RightChild = L;
                L.GrandParent = P.Parent;
                L.Uncle = sibling(L.Parent);
                
            }
            else
            {
                L.Parent = null;
                L.GrandParent = null;
                Root = L;
                L.Uncle = null;
            }
            if (node.LeftChild != null)
            {
                node.LeftChild.GrandParent = node.Parent;
                node.LeftChild.Uncle = sibling(node);
            }
            node.GrandParent = node.Parent.Parent;
            node.Uncle = sibling(node.Parent);


        }

        #endregion

        #region Balancing

        public virtual void Balancing(Y2BinaryTreeNode<T> node)
        {
            if (node.Parent == null) //case1
                node.Color = 2; // node is root
            else 
            {
                if (node.Parent.Color == 2) //case2
                    return; // tree is still valid
                else
                {
                    if(node.Uncle != null && node.Uncle.Color == 1) //case3
                    {
                        node.Parent.Color = 2;
                        
                        if(node.GrandParent != null) node.GrandParent.Color = 1;
                        if(node.Uncle != null) node.Uncle.Color = 2;
                        Balancing(node.GrandParent);
                    }
                    else  //case4
                    {
                        Y2BinaryTreeNode<T> GP = node.GrandParent;
                        if (GP != null)
                        {
                            if (node == node.Parent.RightChild && node.Parent == GP.LeftChild)
                            {
                                Rotate_Left(node.Parent);
                                node = node.LeftChild;
                            }
                            else if (node == node.Parent.LeftChild && node.Parent == GP.RightChild)
                            {
                                Rotate_Right(node.Parent);
                                node = node.RightChild;
                            }
                        }

                        //case5

                        node.Parent.Color = 2;
                        if (GP != null)
                        {
                            GP.Color = 1;
                            if (node == node.Parent.LeftChild && node.Parent == GP.LeftChild) Rotate_Right(GP);
                            else Rotate_Left(GP);
                        }

                    }
                }

            }
        }

        #endregion

        #region Add Node
        public virtual void Add(params T[] values)
        {
            Array.ForEach(values, value => Add(value));
        }
        public virtual bool Add(T value)
        {
            Y2BinaryTreeNode<T> node = new Y2BinaryTreeNode<T>(value);
            node.Color = 1;
            if (Root == null)
            {
                Count++;
                Root = node;
                Balancing(node);
                return true;
            }

            return Add(Root, node);
        }
        private bool Add(Y2BinaryTreeNode<T> parentNode, Y2BinaryTreeNode<T> node)
        {
            if (parentNode.Value.Equals(node.Value))
                return false;

            if (parentNode > node)
            {
                if (parentNode.LeftChild == null)
                {
                    parentNode.LeftChild = node;
                    node.Parent = parentNode;
                    if (parentNode.Parent != null)
                    {
                        node.GrandParent = parentNode.Parent;
                        if (node.GrandParent.RightChild == node.Parent) node.Uncle = node.GrandParent.LeftChild; else node.Uncle = node.GrandParent.RightChild;
                    }
                    Count++;
                    Balancing(node);
                    return true;
                }
                else
                    return Add(parentNode.LeftChild, node);
            }
            else
            {
                if (parentNode.RightChild == null)
                {
                    parentNode.RightChild = node;
                    node.Parent = parentNode;
                    if (parentNode.Parent != null)
                    {
                        node.GrandParent = parentNode.Parent;
                        if (node.GrandParent.RightChild == node.Parent) node.Uncle = node.GrandParent.LeftChild; else node.Uncle = node.GrandParent.RightChild;
                    }
                    Count++;
                    Balancing(node);
                    return true;
                }
                else
                    return Add(parentNode.RightChild, node);
            }
        }
        #endregion

        public virtual void ClearChildren(Y2BinaryTreeNode<T> node)
        {

            if (node.HasLeftChild)
            {
                ClearChildren(node.LeftChild);
                node.LeftChild.Parent = null;
                node.LeftChild.GrandParent = null;
                node.LeftChild.Uncle = null;
                node.LeftChild = null;
            }
            if (node.HasRightChild)
            {
                ClearChildren(node.RightChild);
                node.RightChild.Parent = null;
                node.RightChild.GrandParent = null;
                node.RightChild.Uncle = null;
                node.RightChild = null;
            }
        }

        public virtual void Clear()
        {
            if (Root == null)
                return;
            ClearChildren(Root);
            Root = null;
            Count = 0;
        }

        public virtual int GetHeight()
        {
            return this.GetHeight(this.Root);
        }
        private int GetHeight(Y2BinaryTreeNode<T> startNode)
        {
            if (startNode == null)
                return 0;
            else
                return 1 + Math.Max(GetHeight(startNode.LeftChild), GetHeight(startNode.RightChild));
        }
        public virtual Y2BinaryTreeNode<T> Search(T value)
        {
            return Search(Root, value);
        }
        public virtual Y2BinaryTreeNode<T> Search(Y2BinaryTreeNode<T> node, T value)
        {
            if (node == null)
                return null;

            if (node.Value.Equals(value))
                return node;
            else
            {
                if (node.Value.CompareTo(value) > 0)
                    return Search(node.LeftChild, value);
                else
                    return Search(node.RightChild, value);
            }
        }
        public virtual Queue<T> FindPath(T value)
        {
            Queue<T> q = new Queue<T>();

            Y2BinaryTreeNode<T> node = this.Root;
            bool isFounded = false;

            while (node != null)
            {
                if (node.Value.Equals(value))
                {
                    isFounded = true;
                    break;
                }
                else
                {
                    if (node.Value.CompareTo(value) > 0)
                        node = node.LeftChild;
                    else
                        node = node.RightChild;

                    if (node != null) q.Enqueue(node.Value);
                }
            }
            if (!isFounded)
            {
                q.Clear();
                q = null;
            }

            return q;
        }

        public virtual Y2BinaryTreeNode<T> sibling(Y2BinaryTreeNode<T> node)
        {
            if (node.Parent == null) return null;
            if (!node.Parent.HasLeftChild || !node.Parent.HasRightChild) return null;
            
            if (node.Parent.LeftChild == node) return node.Parent.RightChild;
            else if (node.Parent.RightChild == node) return node.Parent.LeftChild;
            return null;
        }

        public virtual void Delete_Balancing(Y2BinaryTreeNode<T> n)
        {
            
            if (n.Parent == null) //case1
            {
                return;
            }
            else if (sibling(n).Color == 1) //case2
            {
                n.Parent.Color = 1;
                sibling(n).Color = 2;
                if (n == n.Parent.LeftChild) Rotate_Left(n.Parent);
                else Rotate_Right(n.Parent);
            }

            if(n.Parent.Color == 2 && sibling(n).Color == 2 && sibling(n).LeftChild.Color == 2 && sibling(n).RightChild.Color == 2) //case3
            {
                sibling(n).Color = 1;
                Delete_Balancing(n.Parent);
            }
            else if(n.Parent.Color == 1 && sibling(n).Color == 2 && sibling(n).LeftChild.Color == 2 && sibling(n).RightChild.Color == 2) //case4
            {
                sibling(n).Color = 1;
                n.Parent.Color = 2;
            }
            else if(n == n.Parent.LeftChild && sibling(n).Color == 2 && sibling(n).LeftChild.Color == 1 && sibling(n).RightChild.Color == 2) //case5.1
            {
                sibling(n).Color = 1;
                sibling(n).LeftChild.Color = 2;
                Rotate_Right(sibling(n));
            }
            else if(n == n.Parent.RightChild && sibling(n).Color == 2 && sibling(n).RightChild.Color == 1 && sibling(n).LeftChild.Color == 2) //case5.2
            {
                sibling(n).Color = 1;
                sibling(n).RightChild.Color = 2;
                Rotate_Left(sibling(n));
            }

            //case6

            sibling(n).Color = n.Parent.Color;
            n.Parent.Color = 2;
            if(n == n.Parent.LeftChild && sibling(n).RightChild.Color == 1)
            {
                
                sibling(n).RightChild.Color = 2;
                Rotate_Left(n.Parent);
            }
            else if (n == n.Parent.LeftChild && sibling(n).LeftChild.Color == 1)
            {
                sibling(n).LeftChild.Color = 2;
                Rotate_Right(n.Parent);
            }
        }

        public virtual bool Remove(T value)
        {
            return Remove(Root, value);
        }

        private bool Remove(Y2BinaryTreeNode<T> node, T value)
        {
            if (node == null)
                return false;

            Y2BinaryTreeNode<T> S = sibling(node);

            if (node.Value.Equals(value))
            {
                if (node.IsLeaf) // no children
                {
                    if (node == Root) Root = null;
                    else
                    {
                        
                        if (node.Parent.LeftChild == node)
                        {
                            node.Parent.LeftChild = null;
                            if (S != null && !S.IsLeaf) Rotate_Left(node.Parent);
                        }
                        else
                        {
                            node.Parent.RightChild = null;
                            if (S != null && !S.IsLeaf) Rotate_Right(node.Parent);
                        }

                        node.Parent = null;
                        node.GrandParent = null;
                        node.Uncle = null;
                    }
                }
                else if (node.HasLeftChild && node.HasRightChild)   // 2 children
                {
                    // Tìm successor node
                    Y2BinaryTreeNode<T> replacementNode = node.RightChild;

                    while (replacementNode.HasLeftChild)
                    {
                        replacementNode = replacementNode.LeftChild;
                    }
                    node.Value = replacementNode.Value;

                    Remove(replacementNode, replacementNode.Value);
                }
                else    // one child
                {
                    Y2BinaryTreeNode<T> Pa = node.Parent;
                    Y2BinaryTreeNode<T> subNode;

                    if (node.HasLeftChild)
                    {
                        subNode = node.LeftChild;
                        node.LeftChild = null;
                    }
                    else
                    {
                        subNode = node.RightChild;
                        node.RightChild = null;
                    }



                    if (node == Root)
                    {
                        subNode.Parent = null;
                        subNode.GrandParent = null;
                        subNode.Uncle = null;
                        Root = subNode;
                    }

                    else
                    {
                        subNode.Parent = node.Parent;
                        subNode.Uncle = sibling(subNode.Parent);
                        if (node.Parent.LeftChild == node)
                        {
                            node.Parent.LeftChild = subNode;
                             
                        }
                        else
                        { 
                            node.Parent.RightChild = subNode;
                        }
                    }

                    node.Parent = null;
                    node.GrandParent = null;
                    node.Uncle = null;
                    

                    // node is red => tree is still valid

                    if (node.Color == 2) //node is black
                    {
                        if(subNode.Color == 1) //subnode is red
                        {
                            if (Pa.LeftChild == subNode) Pa.LeftChild.Color = 2;
                            else Pa.RightChild.Color = 2;
                        }
                        else //node and subnode is both black
                        {
                            Delete_Balancing(subNode);


                        }
                    }
                }
                Count--;
                return true;
            }
            else
            {
                if (node.Value.CompareTo(value) > 0)
                    return Remove(node.LeftChild, value);
                else
                    return Remove(node.RightChild, value);
            }
        }




    }


}