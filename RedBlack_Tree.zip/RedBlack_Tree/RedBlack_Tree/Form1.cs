﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RedBlack_Tree
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            this.Text = Application.ProductName + " " + Application.ProductVersion;

            
            lblMessage.Text = String.Empty;
            lblNodeCount.Text = String.Empty;
        }

        void UpdateInfo()
        {
            lblNodeCount.Text = "Node Count: " + treePanel1.NodeCount;
            lblTreeHeight.Text = "Tree Height: " + treePanel1.TreeHeight;
        }

        private void InsertButton_Click(object sender, EventArgs e)
        {
            lblMessage.Text = String.Empty;
            if (!treePanel1.AddNode((int)numericUpDown1.Value))
                lblMessage.Text = "Tree already contain an node with that value";
            else
                UpdateInfo();
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            lblMessage.Text = String.Empty;
            if (!treePanel1.DeleteNode((int)numericUpDown1.Value))
                lblMessage.Text = "Tree does not contain value " + numericUpDown1.Value;
            else
                UpdateInfo();
        }

        private void FindButton_Click(object sender, EventArgs e)
        {
            lblMessage.Text = String.Empty;
            if (!treePanel1.SearchNode((int)numericUpDown1.Value))
                lblMessage.Text = "Tree does not contain value " + numericUpDown1.Value;
            else
                UpdateInfo();
        }
    }
}
